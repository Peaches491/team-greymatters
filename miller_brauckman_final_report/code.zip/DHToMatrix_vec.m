function [ T ] = DHToMatrix_vec( p )
%DHTOMATRIX Summary of this function goes here
%   Detailed explanation goes here

T = DHToMatrix(p(1), p(2), p(3), p(4));
end
