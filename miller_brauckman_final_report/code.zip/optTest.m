function [ f ] = optTest( L1, L2, r1, r2 )
    
    
    
end

